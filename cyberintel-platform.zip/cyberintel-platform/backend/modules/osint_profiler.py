"""
OSINT Actor Profiling Module
Aggregates intelligence from multiple sources given an email, username, phone, or domain.
"""

import os
import httpx
import asyncio
from datetime import datetime

HUNTER_API_KEY = os.getenv("HUNTER_API_KEY")
NUMVERIFY_API_KEY = os.getenv("NUMVERIFY_API_KEY")
HIBP_API_KEY = os.getenv("HIBP_API_KEY")
WHOISXML_API_KEY = os.getenv("WHOISXML_API_KEY")


async def run_osint_profile(query: str, query_type: str) -> dict:
    """
    Main entry point. Routes to sub-collectors based on query_type.
    """
    profile = {
        "query": query,
        "query_type": query_type,
        "timestamp": datetime.utcnow().isoformat(),
        "sources": [],
        "risk_score": 0,
        "findings": {}
    }

    tasks = []

    if query_type == "email":
        tasks = [
            _check_hibp(query),
            _check_hunter_email(query),
            _check_email_format(query),
        ]
    elif query_type == "username":
        tasks = [
            _check_username_social(query),
        ]
    elif query_type == "phone":
        tasks = [
            _check_numverify(query),
        ]
    elif query_type == "domain":
        tasks = [
            _check_whois(query),
            _check_hunter_domain(query),
        ]
    else:
        raise ValueError(f"Unsupported query_type: {query_type}")

    results = await asyncio.gather(*tasks, return_exceptions=True)

    for r in results:
        if isinstance(r, Exception):
            profile["sources"].append({"error": str(r)})
        elif r:
            profile["sources"].append(r)
            profile["findings"].update(r.get("data", {}))

    profile["risk_score"] = _calculate_risk_score(profile["findings"])
    return profile


async def _check_hibp(email: str) -> dict:
    """Check HaveIBeenPwned for breach data."""
    if not HIBP_API_KEY:
        return {"source": "HIBP", "status": "no_api_key", "data": {}}
    
    url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
    headers = {
        "hibp-api-key": HIBP_API_KEY,
        "User-Agent": "CyberIntel-Platform"
    }
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                breaches = resp.json()
                return {
                    "source": "HaveIBeenPwned",
                    "status": "found",
                    "data": {
                        "breach_count": len(breaches),
                        "breaches": [b["Name"] for b in breaches],
                        "most_recent": max(b["BreachDate"] for b in breaches) if breaches else None
                    }
                }
            elif resp.status_code == 404:
                return {"source": "HaveIBeenPwned", "status": "clean", "data": {"breach_count": 0}}
        except Exception as e:
            return {"source": "HaveIBeenPwned", "status": "error", "data": {"error": str(e)}}


async def _check_hunter_email(email: str) -> dict:
    """Verify email deliverability and domain reputation via Hunter.io."""
    if not HUNTER_API_KEY:
        return {"source": "Hunter.io", "status": "no_api_key", "data": {}}
    
    url = f"https://api.hunter.io/v2/email-verifier?email={email}&api_key={HUNTER_API_KEY}"
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, timeout=10)
            if resp.status_code == 200:
                d = resp.json().get("data", {})
                return {
                    "source": "Hunter.io",
                    "status": "success",
                    "data": {
                        "deliverable": d.get("result"),
                        "score": d.get("score"),
                        "disposable": d.get("disposable"),
                        "webmail": d.get("webmail"),
                        "mx_records": d.get("mx_records"),
                    }
                }
        except Exception as e:
            return {"source": "Hunter.io", "status": "error", "data": {"error": str(e)}}


async def _check_hunter_domain(domain: str) -> dict:
    """Get domain intelligence via Hunter.io."""
    if not HUNTER_API_KEY:
        return {"source": "Hunter.io Domain", "status": "no_api_key", "data": {}}
    
    url = f"https://api.hunter.io/v2/domain-search?domain={domain}&api_key={HUNTER_API_KEY}"
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, timeout=10)
            if resp.status_code == 200:
                d = resp.json().get("data", {})
                return {
                    "source": "Hunter.io Domain",
                    "status": "success",
                    "data": {
                        "organization": d.get("organization"),
                        "country": d.get("country"),
                        "email_count": d.get("emails", []),
                        "pattern": d.get("pattern"),
                    }
                }
        except Exception as e:
            return {"source": "Hunter.io Domain", "status": "error", "data": {"error": str(e)}}


async def _check_whois(domain: str) -> dict:
    """WHOIS lookup via WhoisXML API."""
    if not WHOISXML_API_KEY:
        return {"source": "WHOIS", "status": "no_api_key", "data": {}}
    
    url = f"https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey={WHOISXML_API_KEY}&domainName={domain}&outputFormat=JSON"
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, timeout=10)
            if resp.status_code == 200:
                d = resp.json().get("WhoisRecord", {})
                registrant = d.get("registrant", {})
                return {
                    "source": "WHOIS",
                    "status": "success",
                    "data": {
                        "registrar": d.get("registrarName"),
                        "created": d.get("createdDate"),
                        "expires": d.get("expiresDate"),
                        "updated": d.get("updatedDate"),
                        "registrant_name": registrant.get("name"),
                        "registrant_org": registrant.get("organization"),
                        "registrant_country": registrant.get("country"),
                        "privacy_protected": registrant.get("name", "").lower().find("privacy") != -1,
                    }
                }
        except Exception as e:
            return {"source": "WHOIS", "status": "error", "data": {"error": str(e)}}


async def _check_numverify(phone: str) -> dict:
    """Validate and enrich phone number via NumVerify."""
    if not NUMVERIFY_API_KEY:
        return {"source": "NumVerify", "status": "no_api_key", "data": {}}
    
    url = f"http://apilayer.net/api/validate?access_key={NUMVERIFY_API_KEY}&number={phone}&format=1"
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, timeout=10)
            if resp.status_code == 200:
                d = resp.json()
                return {
                    "source": "NumVerify",
                    "status": "success",
                    "data": {
                        "valid": d.get("valid"),
                        "country": d.get("country_name"),
                        "carrier": d.get("carrier"),
                        "line_type": d.get("line_type"),
                        "location": d.get("location"),
                        "international_format": d.get("international_format"),
                    }
                }
        except Exception as e:
            return {"source": "NumVerify", "status": "error", "data": {"error": str(e)}}


async def _check_email_format(email: str) -> dict:
    """Basic email format and domain analysis (no API required)."""
    import re
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    is_valid = bool(re.match(pattern, email))
    
    disposable_domains = [
        "mailinator.com", "guerrillamail.com", "tempmail.com",
        "throwaway.email", "yopmail.com", "sharklasers.com",
        "10minutemail.com", "trashmail.com"
    ]
    
    domain = email.split("@")[-1].lower() if "@" in email else ""
    is_disposable = domain in disposable_domains
    
    return {
        "source": "Format Analysis",
        "status": "success",
        "data": {
            "format_valid": is_valid,
            "domain": domain,
            "is_disposable": is_disposable,
        }
    }


async def _check_username_social(username: str) -> dict:
    """
    Check username availability across major platforms.
    Infers registration by checking known URL patterns.
    """
    platforms = {
        "GitHub": f"https://github.com/{username}",
        "Twitter": f"https://twitter.com/{username}",
        "Instagram": f"https://instagram.com/{username}",
        "Reddit": f"https://reddit.com/user/{username}",
        "TikTok": f"https://tiktok.com/@{username}",
    }
    
    found = []
    not_found = []
    
    async with httpx.AsyncClient(follow_redirects=True) as client:
        for platform, url in platforms.items():
            try:
                resp = await client.get(url, timeout=8)
                if resp.status_code == 200:
                    found.append({"platform": platform, "url": url})
                else:
                    not_found.append(platform)
            except Exception:
                not_found.append(platform)
    
    return {
        "source": "Social Platforms",
        "status": "success",
        "data": {
            "username": username,
            "found_on": found,
            "not_found_on": not_found,
            "platform_count": len(found)
        }
    }


def _calculate_risk_score(findings: dict) -> int:
    """
    Calculate a 0-100 risk score from aggregated findings.
    """
    score = 0
    
    if findings.get("breach_count", 0) > 0:
        score += min(findings["breach_count"] * 10, 40)
    
    if findings.get("is_disposable"):
        score += 30
    
    if findings.get("privacy_protected"):
        score += 10
    
    if findings.get("deliverable") == "undeliverable":
        score += 20
    
    if findings.get("line_type") == "voip":
        score += 15
    
    return min(score, 100)
