"""
Crypto Wallet Tracer Module
Traces wallet transactions, flags known scam addresses, builds transaction graphs.
Supports ETH, BTC, BNB.
"""

import os
import httpx
from datetime import datetime

ETHERSCAN_API_KEY = os.getenv("ETHERSCAN_API_KEY")
BSCSCAN_API_KEY = os.getenv("BSCSCAN_API_KEY")
BLOCKCHAIN_API_KEY = os.getenv("BLOCKCHAIN_API_KEY")  # blockchain.info

# Known scam/blacklist addresses (expandable database)
KNOWN_SCAM_ADDRESSES = set([
    # Add known scam addresses here — populate from threat feeds
])


async def trace_wallet(address: str, chain: str = "eth") -> dict:
    """
    Main tracer entry point. Returns transaction history,
    risk flags, and graph-ready node/edge data.
    """
    address = address.strip().lower()
    result = {
        "address": address,
        "chain": chain,
        "timestamp": datetime.utcnow().isoformat(),
        "risk_flags": [],
        "risk_score": 0,
        "transactions": [],
        "connected_wallets": [],
        "graph": {"nodes": [], "edges": []},
        "summary": {}
    }

    if chain == "eth":
        await _trace_eth(address, result)
    elif chain == "btc":
        await _trace_btc(address, result)
    elif chain == "bnb":
        await _trace_bnb(address, result)
    else:
        raise ValueError(f"Unsupported chain: {chain}")

    # Blacklist check
    if address in KNOWN_SCAM_ADDRESSES:
        result["risk_flags"].append("ADDRESS_IN_SCAM_DATABASE")
        result["risk_score"] += 80

    result["risk_score"] = min(result["risk_score"], 100)
    return result


async def _trace_eth(address: str, result: dict):
    """Trace Ethereum wallet via Etherscan."""
    if not ETHERSCAN_API_KEY:
        result["risk_flags"].append("NO_ETHERSCAN_API_KEY")
        return

    base = "https://api.etherscan.io/api"

    async with httpx.AsyncClient() as client:
        # Get normal transactions
        txn_resp = await client.get(base, params={
            "module": "account",
            "action": "txlist",
            "address": address,
            "startblock": 0,
            "endblock": 99999999,
            "page": 1,
            "offset": 50,
            "sort": "desc",
            "apikey": ETHERSCAN_API_KEY
        }, timeout=15)

        # Get ETH balance
        bal_resp = await client.get(base, params={
            "module": "account",
            "action": "balance",
            "address": address,
            "tag": "latest",
            "apikey": ETHERSCAN_API_KEY
        }, timeout=10)

    txn_data = txn_resp.json() if txn_resp.status_code == 200 else {}
    bal_data = bal_resp.json() if bal_resp.status_code == 200 else {}

    txns = txn_data.get("result", [])
    if isinstance(txns, list):
        result["transactions"] = [
            {
                "hash": t.get("hash"),
                "from": t.get("from"),
                "to": t.get("to"),
                "value_eth": int(t.get("value", 0)) / 1e18,
                "timestamp": datetime.fromtimestamp(int(t.get("timeStamp", 0))).isoformat(),
                "status": "success" if t.get("isError") == "0" else "failed",
                "gas_used": t.get("gasUsed"),
            }
            for t in txns[:50]
        ]

        # Build graph
        nodes = {address: {"id": address, "type": "subject", "tx_count": len(txns)}}
        edges = []
        connected = set()

        for t in txns[:20]:
            frm = t.get("from", "").lower()
            to = t.get("to", "").lower()
            val = int(t.get("value", 0)) / 1e18

            for addr in [frm, to]:
                if addr and addr != address and addr not in nodes:
                    nodes[addr] = {"id": addr, "type": "connected", "tx_count": 1}
                    connected.add(addr)

            edges.append({
                "source": frm,
                "target": to,
                "value_eth": val,
                "hash": t.get("hash")
            })

            # Flag large outflows
            if to != address and val > 1.0:
                result["risk_flags"].append(f"LARGE_OUTFLOW_{val:.2f}_ETH_TO_{to[:10]}")
                result["risk_score"] += 15

        result["graph"]["nodes"] = list(nodes.values())
        result["graph"]["edges"] = edges
        result["connected_wallets"] = list(connected)[:20]

    # Balance
    balance_wei = int(bal_data.get("result", 0))
    result["summary"] = {
        "balance_eth": balance_wei / 1e18,
        "transaction_count": len(result["transactions"]),
        "connected_wallet_count": len(result["connected_wallets"])
    }

    # Risk: newly created wallet with high volume
    if len(result["transactions"]) > 20 and result["summary"]["balance_eth"] < 0.001:
        result["risk_flags"].append("HIGH_VOLUME_NEAR_ZERO_BALANCE")
        result["risk_score"] += 25


async def _trace_btc(address: str, result: dict):
    """Trace Bitcoin wallet via Blockchain.info."""
    url = f"https://blockchain.info/rawaddr/{address}?limit=50"

    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, timeout=15)
            if resp.status_code != 200:
                result["risk_flags"].append("BTC_LOOKUP_FAILED")
                return

            data = resp.json()
            txns = data.get("txs", [])

            result["transactions"] = [
                {
                    "hash": t.get("hash"),
                    "time": datetime.fromtimestamp(t.get("time", 0)).isoformat(),
                    "inputs": [i.get("prev_out", {}).get("addr") for i in t.get("inputs", [])],
                    "outputs": [o.get("addr") for o in t.get("out", [])],
                    "value_btc": sum(o.get("value", 0) for o in t.get("out", [])) / 1e8
                }
                for t in txns[:50]
            ]

            result["summary"] = {
                "balance_btc": data.get("final_balance", 0) / 1e8,
                "total_received_btc": data.get("total_received", 0) / 1e8,
                "transaction_count": data.get("n_tx", 0)
            }

        except Exception as e:
            result["risk_flags"].append(f"BTC_ERROR: {str(e)}")


async def _trace_bnb(address: str, result: dict):
    """Trace BNB Smart Chain wallet via BscScan."""
    if not BSCSCAN_API_KEY:
        result["risk_flags"].append("NO_BSCSCAN_API_KEY")
        return

    base = "https://api.bscscan.com/api"

    async with httpx.AsyncClient() as client:
        txn_resp = await client.get(base, params={
            "module": "account",
            "action": "txlist",
            "address": address,
            "startblock": 0,
            "endblock": 99999999,
            "page": 1,
            "offset": 50,
            "sort": "desc",
            "apikey": BSCSCAN_API_KEY
        }, timeout=15)

    txns = txn_resp.json().get("result", []) if txn_resp.status_code == 200 else []

    if isinstance(txns, list):
        result["transactions"] = [
            {
                "hash": t.get("hash"),
                "from": t.get("from"),
                "to": t.get("to"),
                "value_bnb": int(t.get("value", 0)) / 1e18,
                "timestamp": datetime.fromtimestamp(int(t.get("timeStamp", 0))).isoformat(),
                "status": "success" if t.get("isError") == "0" else "failed"
            }
            for t in txns[:50]
        ]

        result["summary"] = {
            "transaction_count": len(result["transactions"]),
            "chain": "BSC"
        }
